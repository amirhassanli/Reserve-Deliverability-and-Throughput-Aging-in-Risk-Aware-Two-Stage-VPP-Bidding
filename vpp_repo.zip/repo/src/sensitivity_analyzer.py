"""
Sensitivity Analyzer Module
3D sensitivity sweep on c_cap, beta, and PV penetration
"""

import numpy as np
import pandas as pd
import json
import time
from pathlib import Path
from tqdm import tqdm
import yaml
import sys
sys.path.append(str(Path(__file__).parent))

from model_formulation import VPPModel
from pyomo.environ import TerminationCondition


class SensitivityAnalyzer:
    def __init__(self, config_path="config/config.yaml"):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.output_dir = Path("output")
        self.results_dir = self.output_dir / "results"
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # Load sensitivity parameters
        self.c_cap_range = self.config['sensitivity']['c_cap']
        self.beta_range = self.config['sensitivity']['beta']
        self.pv_range = self.config['sensitivity']['pv_penetration']
        
        # Load network
        with open("data/processed/network_data.json", 'r') as f:
            self.network = json.load(f)
        
        # Load scenarios for day 0 (use one day for sensitivity)
        with open("data/processed/scenario_data/scenarios_day_0.json", 'r') as f:
            day_data = json.load(f)
        self.scenarios = day_data['scenarios']
    
    def run_sensitivity_sweep(self):
        """Run 3D sensitivity sweep"""
        total_points = len(self.c_cap_range) * len(self.beta_range) * len(self.pv_range)
        print(f"🔬 Running sensitivity sweep: {total_points} points")
        print(f"   c_cap: {len(self.c_cap_range)} points")
        print(f"   beta: {len(self.beta_range)} points")
        print(f"   PV penetration: {len(self.pv_range)} points")
        
        results = []
        seed = 42  # Fixed seed for sensitivity
        
        for c_cap in tqdm(self.c_cap_range, desc="c_cap"):
            for beta in self.beta_range:
                for pv_pen in self.pv_range:
                    # Update config
                    self.config['battery_replacement_cost'] = c_cap * 1000  # USD/MWh
                    self.config['cvar_beta'] = beta
                    
                    # Scale solar scenarios
                    scaled_scenarios = []
                    for sc in self.scenarios:
                        scaled = sc.copy()
                        # Scale solar by PV penetration (normalized to 50% base)
                        base_pv = 0.5
                        scaled['solar'] = [s * (pv_pen / base_pv) for s in sc['solar']]
                        scaled_scenarios.append(scaled)
                    
                    # Build and solve model (Full case)
                    model = VPPModel(self.config, self.network)
                    model.build_model(scaled_scenarios)
                    
                    start_time = time.time()
                    result_obj, solve_time = model.solve(seed=seed, tee=False)
                    solve_time = time.time() - start_time
                    
                    if result_obj.solver.termination_condition == TerminationCondition.optimal:
                        extracted = model.extract_results()
                        extracted['c_cap'] = c_cap
                        extracted['beta'] = beta
                        extracted['pv_penetration'] = pv_pen
                        extracted['solve_time'] = solve_time
                        results.append(extracted)
        
        # Save results
        df = pd.DataFrame(results)
        output_path = self.results_dir / "sensitivity_results_3d.csv"
        df.to_csv(output_path, index=False)
        print(f"✅ Sensitivity results saved to {output_path}")
        
        # Compute summary statistics
        summary = df.groupby(['c_cap', 'beta', 'pv_penetration']).agg({
            'expected_profit': 'mean'
        }).round(2)
        summary_path = self.results_dir / "sensitivity_summary.csv"
        summary.to_csv(summary_path)
        print(f"✅ Sensitivity summary saved to {summary_path}")
        
        return df, summary


if __name__ == "__main__":
    analyzer = SensitivityAnalyzer()
    df, summary = analyzer.run_sensitivity_sweep()