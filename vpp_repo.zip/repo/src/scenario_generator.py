"""
scenario_generator.py — FULL VERSION
Generates and reduces scenarios for stochastic programming
"""

import numpy as np
import pandas as pd
import json
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')


class ScenarioGenerator:
    def __init__(self, data_dir="data", config=None):
        self.data_dir = Path(data_dir)
        self.processed_dir = self.data_dir / "processed"
        self.scenario_dir = self.processed_dir / "scenario_data"
        self.scenario_dir.mkdir(parents=True, exist_ok=True)
        
        self.n_initial = 1000
        self.n_final = 50
        self.horizon = 24
        
        # Load saved data if available
        self.load_data = None
        self.renewable_data = None
        self.price_data = None
        self._load_saved_data()
    
    def _load_saved_data(self):
        """Load saved data from processed directory"""
        try:
            load_path = self.processed_dir / "load_data.csv"
            if load_path.exists():
                self.load_data = pd.read_csv(load_path)
                self.load_data['timestamp'] = pd.to_datetime(self.load_data['timestamp'])
                print(f"✅ Loaded load_data.csv: {len(self.load_data)} rows")
            
            ren_path = self.processed_dir / "renewable_data.csv"
            if ren_path.exists():
                self.renewable_data = pd.read_csv(ren_path)
                self.renewable_data['timestamp'] = pd.to_datetime(self.renewable_data['timestamp'])
                print(f"✅ Loaded renewable_data.csv: {len(self.renewable_data)} rows")
            
            price_path = self.processed_dir / "price_data.csv"
            if price_path.exists():
                self.price_data = pd.read_csv(price_path)
                self.price_data['timestamp'] = pd.to_datetime(self.price_data['timestamp'])
                print(f"✅ Loaded price_data.csv: {len(self.price_data)} rows")
        except Exception as e:
            print(f"⚠️ Could not load saved data: {e}")
    
    def get_day_data(self, day_idx):
        """
        Get data for a specific day (24 hours)
        Uses synthetic data if real data not available
        """
        # If real data is available, use it
        if self.load_data is not None:
            try:
                base_time = pd.Timestamp('2023-01-01')
                start_time = base_time + pd.Timedelta(days=day_idx)
                end_time = start_time + pd.Timedelta(hours=24)
                
                load_day = self.load_data[
                    (self.load_data['timestamp'] >= start_time) & 
                    (self.load_data['timestamp'] < end_time)
                ]
                
                if len(load_day) >= 24:
                    load_mw = load_day['load_mw'].values[:24]
                    
                    # Get renewable data
                    if self.renewable_data is not None:
                        ren_day = self.renewable_data[
                            (self.renewable_data['timestamp'] >= start_time) & 
                            (self.renewable_data['timestamp'] < end_time)
                        ]
                        solar_mw = ren_day['solar_power_mw'].values[:24] if len(ren_day) >= 24 else np.zeros(24)
                        wind_mw = ren_day['wind_power_mw'].values[:24] if len(ren_day) >= 24 else np.zeros(24)
                    else:
                        solar_mw = np.zeros(24)
                        wind_mw = np.zeros(24)
                    
                    # Get price data
                    if self.price_data is not None:
                        price_day = self.price_data[
                            (self.price_data['timestamp'] >= start_time) & 
                            (self.price_data['timestamp'] < end_time)
                        ]
                        price = price_day['price_dayahead_eur_mwh'].values[:24] if len(price_day) >= 24 else np.ones(24) * 40
                    else:
                        price = np.ones(24) * 40
                    
                    return {
                        'load_mw': load_mw,
                        'solar_mw': solar_mw,
                        'wind_mw': wind_mw,
                        'price_eur_mwh': price
                    }
            except Exception as e:
                print(f"⚠️ Error loading real data for day {day_idx}: {e}")
        
        # Fallback: synthetic data
        return self._generate_synthetic_day(day_idx)
    
    def _generate_synthetic_day(self, day_idx):
        """Generate synthetic day data with realistic patterns"""
        t = np.arange(24)
        
        # Load pattern: double peak (8am and 6pm)
        load = 12 + 4 * np.sin(2 * np.pi * (t - 8) / 24) + 3 * np.sin(2 * np.pi * (t - 18) / 12)
        
        # Solar: peak at noon
        solar = np.maximum(0, 8 * np.sin(np.pi * (t - 5) / 12))
        
        # Wind: variable with diurnal pattern
        wind = 3 + 2 * np.sin(2 * np.pi * t / 12) + np.random.normal(0, 0.5, 24)
        wind = np.clip(wind, 0, 6)
        
        # Price: higher during peak hours
        price = 35 + 15 * np.sin(2 * np.pi * (t - 12) / 24) + np.random.normal(0, 3, 24)
        price = np.clip(price, 10, 70)
        
        return {
            'load_mw': load,
            'solar_mw': solar,
            'wind_mw': wind,
            'price_eur_mwh': price
        }
    
    def generate_scenarios_for_day(self, day_idx):
        """Generate correlated scenarios for a specific day"""
        day_data = self.get_day_data(day_idx)
        
        load_base = day_data['load_mw']
        solar_base = day_data['solar_mw']
        wind_base = day_data['wind_mw']
        price_base = day_data['price_eur_mwh']
        
        # Standard deviations based on data variability
        load_std = 0.05 * np.mean(load_base) if np.mean(load_base) > 0 else 0.5
        solar_std = 0.15 * np.mean(solar_base) if np.mean(solar_base) > 0 else 0.2
        wind_std = 0.20 * np.mean(wind_base) if np.mean(wind_base) > 0 else 0.3
        price_std = 0.10 * np.mean(price_base) if np.mean(price_base) > 0 else 2.0
        
        # Correlation matrix (renewable negatively correlated with price)
        corr_matrix = np.array([
            [1.0, 0.0, 0.0, -0.3],
            [0.0, 1.0, 0.0, -0.4],
            [0.0, 0.0, 1.0, -0.3],
            [-0.3, -0.4, -0.3, 1.0]
        ])
        L = np.linalg.cholesky(corr_matrix)
        
        scenarios = []
        for s in range(self.n_initial):
            # Generate correlated errors
            z = np.random.normal(0, 1, 4)
            errors = L @ z
            
            # Temporal correlation (random walk)
            temporal_noise = np.random.normal(0, 1, self.horizon)
            temporal_noise = np.cumsum(temporal_noise)
            temporal_noise = temporal_noise / (np.std(temporal_noise) + 1e-6) * 0.5
            
            # Apply errors
            load_scenario = load_base * (1 + 0.05 * errors[0] + 0.02 * temporal_noise)
            solar_scenario = solar_base * (1 + 0.15 * errors[1] + 0.05 * temporal_noise)
            wind_scenario = wind_base * (1 + 0.20 * errors[2] + 0.05 * temporal_noise)
            price_scenario = price_base * (1 + 0.10 * errors[3] + 0.02 * temporal_noise)
            
            # Ensure non-negativity
            load_scenario = np.maximum(load_scenario, 0.5 * np.mean(load_base))
            solar_scenario = np.maximum(solar_scenario, 0)
            wind_scenario = np.maximum(wind_scenario, 0)
            price_scenario = np.maximum(price_scenario, 5)
            
            scenarios.append({
                'load': load_scenario.tolist(),
                'solar': solar_scenario.tolist(),
                'wind': wind_scenario.tolist(),
                'price': price_scenario.tolist(),
            })
        
        return scenarios
    
    def reduce_scenarios_fast_forward(self, scenarios, n_final):
        """Reduce scenarios using Fast Forward Selection"""
        n_initial = len(scenarios)
        if n_initial <= n_final:
            return scenarios
        
        # Convert to matrix
        scenario_vectors = []
        for s in scenarios:
            vec = np.concatenate([s['load'], s['solar'], s['wind'], s['price']])
            scenario_vectors.append(vec)
        
        scenario_matrix = np.array(scenario_vectors)
        
        # Fast Forward Selection
        selected_indices = []
        remaining_indices = list(range(n_initial))
        
        # First: select scenario closest to the mean
        mean_vec = np.mean(scenario_matrix, axis=0)
        distances = np.linalg.norm(scenario_matrix - mean_vec, axis=1)
        first_idx = np.argmin(distances)
        selected_indices.append(first_idx)
        remaining_indices.remove(first_idx)
        
        # Iteratively select
        for _ in range(1, n_final):
            best_idx = None
            best_error = np.inf
            
            for idx in remaining_indices:
                candidate_indices = selected_indices + [idx]
                candidate_centers = scenario_matrix[candidate_indices]
                
                # Distance to nearest selected center
                distances = np.linalg.norm(scenario_matrix[:, None] - candidate_centers[None, :], axis=2)
                min_distances = np.min(distances, axis=1)
                error = np.sum(min_distances)
              
                if error < best_error:
                    best_error = error
                    best_idx = idx
            
            selected_indices.append(best_idx)
            remaining_indices.remove(best_idx)
        
        # Return selected scenarios
        return [scenarios[i] for i in selected_indices]
    
    def generate_and_save_scenarios(self, num_days=28):
        """Generate scenarios for multiple days and save to disk"""
        print(f"📊 Generating scenarios for {num_days} days...")
        
        for day in range(num_days):
            print(f"  Day {day+1}/{num_days}...")
            
            # Generate initial scenarios
            scenarios = self.generate_scenarios_for_day(day)
            
            # Reduce scenarios
            reduced = self.reduce_scenarios_fast_forward(scenarios, self.n_final)
            
            # Save to disk
            day_file = self.scenario_dir / f"scenarios_day_{day}.json"
            with open(day_file, 'w') as f:
                json.dump({
                    'day': day,
                    'timestamp': datetime.now().isoformat(),
                    'num_scenarios': len(reduced),
                    'horizon': self.horizon,
                    'scenarios': reduced
                }, f, indent=2)
            
            print(f"    ✅ Saved {len(reduced)} scenarios to {day_file}")
        
        # Save master index
        index_file = self.scenario_dir / "scenario_index.json"
        with open(index_file, 'w') as f:
            json.dump({
                'num_days': num_days,
                'num_scenarios_per_day': self.n_final,
                'horizon': self.horizon,
                'files': [f"scenarios_day_{d}.json" for d in range(num_days)],
                'created_at': datetime.now().isoformat()
            }, f, indent=2)
        
        print(f"✅ Scenario index saved to {index_file}")
        return [{'day': i, 'scenarios': []} for i in range(num_days)]


# ============================================================
# Quick Test
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("🧪 TESTING SCENARIO GENERATOR")
    print("=" * 60)
    
    generator = ScenarioGenerator()
    scenarios = generator.generate_and_save_scenarios(num_days=3)
    
    print("\n📊 Scenario Summary:")
    for day_data in scenarios:
        print(f"  Day {day_data['day']}: {len(day_data['scenarios'])} scenarios")
