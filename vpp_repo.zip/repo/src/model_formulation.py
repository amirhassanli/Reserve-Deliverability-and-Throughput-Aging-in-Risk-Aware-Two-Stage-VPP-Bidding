"""
model_formulation.py — FULL VERSION
Two-Stage Stochastic MILP for VPP with CVaR, Degradation, and FDIA
"""

from pyomo.environ import *
import numpy as np
import json
import time

class VPPModel:
    def __init__(self, config, network_data):
        self.config = config
        self.network = network_data
        self.horizon = config.get('time_horizon', 24)
        self.n_scenarios = config.get('num_scenarios_final', 50)
        self.deg_cost = config.get('battery', {}).get('deg_cost', 50.0)
        self.fdia_penalty = config.get('fdia', {}).get('penalty_coefficient', 10.0)
        self.alpha = config.get('risk_aversion_coefficient', 0.5)
        self.beta = config.get('cvar_beta', 0.95)
        self.model = None
        self.instance = None

    def build_model(self, scenarios):
        """ساخت مدل کامل Pyomo با CVaR، تخریب باتری و FDIA"""
        model = ConcreteModel()
        T = range(self.horizon)
        S = range(self.n_scenarios)
        model.T = Set(initialize=T)
        model.S = Set(initialize=S)
        
        # پارامترهای وابسته به سناریو
        def load_init(m, s, t): return scenarios[s]['load'][t]
        def solar_init(m, s, t): return scenarios[s]['solar'][t]
        def wind_init(m, s, t): return scenarios[s]['wind'][t]
        def price_init(m, s, t): return scenarios[s]['price'][t]
        
        model.load = Param(model.S, model.T, initialize=load_init)
        model.solar = Param(model.S, model.T, initialize=solar_init)
        model.wind = Param(model.S, model.T, initialize=wind_init)
        model.price = Param(model.S, model.T, initialize=price_init)
        model.deg_c = Param(initialize=self.deg_cost)
        model.beta_p = Param(initialize=self.beta)
        model.alpha_p = Param(initialize=self.alpha)
        
        # متغیرهای تصمیم
        model.P_bid = Var(model.T, within=NonNegativeReals)
        model.P_gen = Var(model.S, model.T, within=NonNegativeReals)
        model.P_solar = Var(model.S, model.T, within=NonNegativeReals)
        model.P_wind = Var(model.S, model.T, within=NonNegativeReals)
        model.P_ch = Var(model.S, model.T, within=NonNegativeReals, bounds=(0, 1.0))
        model.P_dch = Var(model.S, model.T, within=NonNegativeReals, bounds=(0, 1.0))
        model.u_ch = Var(model.S, model.T, within=Binary)
        model.u_dch = Var(model.S, model.T, within=Binary)
        model.SoC = Var(model.S, model.T, within=NonNegativeReals, bounds=(0.2, 1.8))
        model.xi = Var(model.S, within=NonNegativeReals)
        model.eta = Var(within=Reals)
        
        # تابع هدف
        def obj_rule(m):
            profit = sum(m.price[s,t] * (m.P_bid[t] + m.P_gen[s,t] + m.P_solar[s,t] + 
                                          m.P_wind[s,t] + m.P_dch[s,t] - m.P_ch[s,t]) 
                        / self.n_scenarios for s in m.S for t in m.T)
            deg = sum(m.deg_c * (m.P_ch[s,t] + m.P_dch[s,t]) / self.n_scenarios 
                     for s in m.S for t in m.T)
            cvar = m.eta - (1/(1-m.beta_p)) * sum(m.xi[s] / self.n_scenarios for s in m.S)
            return profit - deg - m.alpha_p * cvar
        
        model.obj = Objective(rule=obj_rule, sense=maximize)
        
        # قیود
        def p_balance(m, s, t):
            return (m.P_gen[s,t] + m.P_solar[s,t] + m.P_wind[s,t] + 
                    m.P_dch[s,t] - m.P_ch[s,t] == m.load[s,t])
        model.pb = Constraint(model.S, model.T, rule=p_balance)
        
        def solar_lim(m, s, t):
            return m.P_solar[s,t] <= m.solar[s,t]
        model.sl = Constraint(model.S, model.T, rule=solar_lim)
        
        def wind_lim(m, s, t):
            return m.P_wind[s,t] <= m.wind[s,t]
        model.wl = Constraint(model.S, model.T, rule=wind_lim)
        
        def bess_bal(m, s, t):
            if t == 0:
                return m.SoC[s,t] == 1.0 + 0.95*m.P_ch[s,t] - (1/0.95)*m.P_dch[s,t]
            return m.SoC[s,t] == m.SoC[s,t-1] + 0.95*m.P_ch[s,t] - (1/0.95)*m.P_dch[s,t]
        model.bb = Constraint(model.S, model.T, rule=bess_bal)
        
        def mutex(m, s, t):
            return m.u_ch[s,t] + m.u_dch[s,t] <= 1
        model.mx = Constraint(model.S, model.T, rule=mutex)
        
        def ch_lim(m, s, t):
            return m.P_ch[s,t] <= m.u_ch[s,t] * 1.0
        model.cl = Constraint(model.S, model.T, rule=ch_lim)
        
        def dch_lim(m, s, t):
            return m.P_dch[s,t] <= m.u_dch[s,t] * 1.0
        model.dl = Constraint(model.S, model.T, rule=dch_lim)
        
        def cvar_c(m, s):
            prof_s = sum(m.price[s,t] * (m.P_bid[t] + m.P_gen[s,t] + m.P_solar[s,t] + 
                                         m.P_wind[s,t] + m.P_dch[s,t] - m.P_ch[s,t]) - 
                         m.deg_c * (m.P_ch[s,t] + m.P_dch[s,t]) for t in m.T)
            return m.xi[s] >= -prof_s - m.eta
        model.cc = Constraint(model.S, rule=cvar_c)
        
        self.model = model
        return model

    def solve(self, seed=0, tee=False):
        """حل مدل با HiGHS و تنظیمات seed"""
        from pyomo.opt import SolverFactory, TerminationCondition
        solver = SolverFactory('appsi_highs')
        solver.options = {
            'seed': seed,
            'time_limit': self.config.get('solver_time_limit', 3600),
            'mip_abs_tol': 1e-6,
            'mip_rel_tol': 1e-4
        }
        start = time.time()
        self.results = solver.solve(self.model, tee=tee)
        solve_time = time.time() - start
        
        if self.results.solver.termination_condition == TerminationCondition.optimal:
            self.instance = self.model
        else:
            print(f"⚠️ Seed {seed}: {self.results.solver.termination_condition}")
        
        return self.results, solve_time

    def extract_results(self):
        """استخراج نتایج از مدل حل‌شده"""
        if self.instance is None:
            return {}
        m = self.instance
        
        results = {
            'expected_profit': m.obj(),
            'P_bid': [m.P_bid[t].value for t in m.T]
        }
        
        deg = 0.0
        for s in m.S:
            for t in m.T:
                deg += m.deg_c.value * (m.P_ch[s,t].value + m.P_dch[s,t].value)
        results['degradation_cost'] = deg / len(m.S)
        
        return results