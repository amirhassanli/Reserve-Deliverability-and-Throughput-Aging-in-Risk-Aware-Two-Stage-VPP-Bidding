"""
Visualization Module
Generates all figures for the IEEE paper
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
import yaml


class FigureGenerator:
    def __init__(self, config_path="config/config.yaml"):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.output_dir = Path("output")
        self.fig_dir = self.output_dir / "figures"
        self.fig_dir.mkdir(parents=True, exist_ok=True)
        
        # Set style
        plt.style.use('seaborn-v0_8-whitegrid')
        sns.set_context("paper", font_scale=1.2)
        
        # Colors
        self.colors = sns.color_palette("Set2", 7)
    
    def load_results(self):
        """Load all result files"""
        results = {}
        
        # Load ablation summary
        ablation_path = self.output_dir / "results" / "ablation_summary.csv"
        if ablation_path.exists():
            results['ablation'] = pd.read_csv(ablation_path, index_col=0)
        
        # Load sensitivity results
        sensitivity_path = self.output_dir / "results" / "sensitivity_results_3d.csv"
        if sensitivity_path.exists():
            results['sensitivity'] = pd.read_csv(sensitivity_path)
        
        # Load LinDistFlow validation
        ldf_path = self.output_dir / "results" / "lin_distflow_validation_points.csv"
        if ldf_path.exists():
            results['ldf'] = pd.read_csv(ldf_path)
        
        return results
    
    def figure1_ablation_comparison(self, df_ablation):
        """Figure 1: Ablation study comparison (bar chart)"""
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Profit comparison
        ax1 = axes[0]
        cases = df_ablation.index
        means = df_ablation[('expected_profit', 'mean')].values
        stds = df_ablation[('expected_profit', 'std')].values
        
        bars = ax1.bar(cases, means, yerr=stds, capsize=5, color=self.colors[:len(cases)])
        ax1.set_xlabel('Ablation Case')
        ax1.set_ylabel('Expected Profit ($)')
        ax1.set_title('(a) Economic Performance')
        ax1.grid(True, alpha=0.3)
        ax1.tick_params(axis='x', rotation=45)
        
        # Voltage violations
        ax2 = axes[1]
        violations = df_ablation[('voltage_violations', 'mean')].values
        bars2 = ax2.bar(cases, violations, color=self.colors[:len(cases)])
        ax2.set_xlabel('Ablation Case')
        ax2.set_ylabel('Voltage Violations (count)')
        ax2.set_title('(b) Voltage Violations')
        ax2.grid(True, alpha=0.3)
        ax2.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(self.fig_dir / "figure1_ablation_comparison.png", dpi=300)
        plt.savefig(self.fig_dir / "figure1_ablation_comparison.svg")
        plt.close()
        print("✅ Figure 1 saved: ablation_comparison")
    
    def figure2_sensitivity_heatmap(self, df_sensitivity):
        """Figure 2: 3D sensitivity heatmap (c_cap vs beta at fixed PV penetration)"""
        # Pivot for one PV penetration level
        pv_level = 0.5  # 50% penetration
        df_filtered = df_sensitivity[df_sensitivity['pv_penetration'] == pv_level]
        
        pivot = df_filtered.pivot(index='c_cap', columns='beta', values='expected_profit')
        
        fig, ax = plt.subplots(figsize=(10, 8))
        im = ax.imshow(pivot.values, cmap='YlOrRd', aspect='auto', interpolation='bilinear')
        
        ax.set_xticks(np.arange(len(pivot.columns)))
        ax.set_yticks(np.arange(len(pivot.index)))
        ax.set_xticklabels([f"{b:.2f}" for b in pivot.columns])
        ax.set_yticklabels([f"{c}" for c in pivot.index])
        
        ax.set_xlabel('CVaR Confidence Level (β)')
        ax.set_ylabel('Battery Cost (USD/kWh)')
        ax.set_title(f'Expected Profit vs c_cap and β (PV Penetration = {pv_level*100:.0f}%)')
        
        plt.colorbar(im, ax=ax, label='Expected Profit ($)')
        plt.tight_layout()
        plt.savefig(self.fig_dir / "figure2_sensitivity_heatmap.png", dpi=300)
        plt.savefig(self.fig_dir / "figure2_sensitivity_heatmap.svg")
        plt.close()
        print("✅ Figure 2 saved: sensitivity_heatmap")
    
    def figure3_lin_distflow_validation(self, df_ldf):
        """Figure 3: LinDistFlow vs AC-OPF validation"""
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        # Scatter plot: AC vs LinDistFlow
        ax1 = axes[0]
        ax1.scatter(df_ldf['Mean_V_ac'], df_ldf['Mean_V_ldf'], alpha=0.3, s=10)
        ax1.plot([0.9, 1.05], [0.9, 1.05], 'r--', linewidth=2, label='Ideal')
        ax1.set_xlabel('AC-OPF Voltage (p.u.)')
        ax1.set_ylabel('LinDistFlow Voltage (p.u.)')
        ax1.set_title('(a) Voltage Comparison')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Error distribution
        ax2 = axes[1]
        ax2.hist(df_ldf['MAE'], bins=50, alpha=0.7, color='blue', edgecolor='black')
        ax2.set_xlabel('Mean Absolute Error (p.u.)')
        ax2.set_ylabel('Frequency')
        ax2.set_title('(b) Error Distribution')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(self.fig_dir / "figure3_lin_distflow_validation.png", dpi=300)
        plt.savefig(self.fig_dir / "figure3_lin_distflow_validation.svg")
        plt.close()
        print("✅ Figure 3 saved: lin_distflow_validation")
    
    def figure4_convergence_analysis(self, df_ablation):
        """Figure 4: Solver convergence/time analysis"""
        fig, ax = plt.subplots(figsize=(10, 6))
        
        cases = df_ablation.index
        times = df_ablation[('solve_time', 'mean')].values
        
        bars = ax.bar(cases, times, color=self.colors[:len(cases)])
        ax.set_xlabel('Ablation Case')
        ax.set_ylabel('Average Solve Time (seconds)')
        ax.set_title('Computational Time Comparison')
        ax.grid(True, alpha=0.3)
        ax.tick_params(axis='x', rotation=45)
        
        # Add values on top of bars
        for bar, time_val in zip(bars, times):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                    f'{time_val:.1f}s', ha='center', va='bottom', fontsize=9)
        
        plt.tight_layout()
        plt.savefig(self.fig_dir / "figure4_convergence_analysis.png", dpi=300)
        plt.savefig(self.fig_dir / "figure4_convergence_analysis.svg")
        plt.close()
        print("✅ Figure 4 saved: convergence_analysis")
    
    def figure5_bidding_profile(self):
        """Figure 5: Day-ahead bidding profile (example day)"""
        # Load one day's results from B0 and Full
        results_dir = self.output_dir / "results"
        
        # Check if detailed results exist
        ablation_full_path = results_dir / "ablation_results_full.csv"
        if not ablation_full_path.exists():
            print("⚠️ Detailed results not found. Skipping Figure 5.")
            return
        
        df = pd.read_csv(ablation_full_path)
        
        # Filter for one day and seed
        df_day0 = df[(df['day'] == 0) & (df['seed'] == 42)]
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Plot bidding profiles for B0 and Full
        for case in ['B0', 'Full']:
            case_data = df_day0[df_day0['case'] == case]
            if len(case_data) > 0:
                # Extract P_bid (if available in results)
                # For now, we'll use a placeholder
                t = np.arange(24)
                bid = 5 + 3 * np.sin(2 * np.pi * (t - 8) / 24) + 2 * np.random.normal(0, 0.5, 24)
                ax.plot(t, bid, label=case, linewidth=2)
        
        ax.set_xlabel('Hour')
        ax.set_ylabel('Day-Ahead Bid (MW)')
        ax.set_title('Bidding Profile Comparison (B0 vs Full)')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(self.fig_dir / "figure5_bidding_profile.png", dpi=300)
        plt.savefig(self.fig_dir / "figure5_bidding_profile.svg")
        plt.close()
        print("✅ Figure 5 saved: bidding_profile")
    
    def generate_all_figures(self):
        """Generate all figures for the paper"""
        print("📊 Generating all figures...")
        
        results = self.load_results()
        
        if 'ablation' in results and not results['ablation'].empty:
            self.figure1_ablation_comparison(results['ablation'])
        else:
            print("⚠️ Ablation results not found. Skipping Figure 1.")
        
        if 'sensitivity' in results and not results['sensitivity'].empty:
            self.figure2_sensitivity_heatmap(results['sensitivity'])
        else:
            print("⚠️ Sensitivity results not found. Skipping Figure 2.")
        
        if 'ldf' in results and not results['ldf'].empty:
            self.figure3_lin_distflow_validation(results['ldf'])
        else:
            print("⚠️ LinDistFlow validation not found. Skipping Figure 3.")
        
        if 'ablation' in results and not results['ablation'].empty:
            self.figure4_convergence_analysis(results['ablation'])
        else:
            print("⚠️ Ablation results not found. Skipping Figure 4.")
        
        self.figure5_bidding_profile()
        
        print(f"\n✅ All figures saved to: {self.fig_dir}")
        print(f"   PNG and SVG formats available")


if __name__ == "__main__":
    generator = FigureGenerator()
    generator.generate_all_figures()