"""
data_loader.py — FULL VERSION
بارگذاری و تولید داده‌های مورد نیاز برای شبیه‌سازی VPP
بدون نیاز به کلید API — تمام داده‌ها به‌صورت سینتتیک با الگوهای واقعی تولید می‌شوند
"""

import pandas as pd
import numpy as np
import json
import os
from pathlib import Path
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


class DataLoader:
    """
    بارگذاری داده‌ها برای بهینه‌سازی VPP
    تمام داده‌ها به‌صورت سینتتیک (Synthetic) با الگوهای واقعی‌گرا تولید می‌شوند
    """
    
    def __init__(self, data_dir="data"):
        self.data_dir = Path(data_dir)
        self.raw_dir = self.data_dir / "raw"
        self.processed_dir = self.data_dir / "processed"
        self.scenario_dir = self.processed_dir / "scenario_data"
        
        # ساخت پوشه‌های مورد نیاز
        for d in [self.raw_dir, self.processed_dir, self.scenario_dir]:
            d.mkdir(parents=True, exist_ok=True)
        for src in ['network']:
            (self.raw_dir / src).mkdir(exist_ok=True)
        
        self.metadata = {
            'created_at': datetime.now().isoformat(),
            'sources': {},
            'data_type': 'synthetic',
            'description': 'Realistic synthetic data for VPP optimization'
        }
        print("✅ DataLoader initialized (Synthetic Mode — No API keys needed)")
    
    def _save_metadata(self):
        """ذخیره‌سازی اطلاعات نسخه‌ی داده‌ها"""
        path = self.processed_dir / "metadata.json"
        self.metadata['updated_at'] = datetime.now().isoformat()
        with open(path, 'w') as f:
            json.dump(self.metadata, f, indent=2)
    
    def load_ieee33_network(self, save=True):
        """
        بارگذاری توپولوژی شبکه IEEE 33-bus
        داده‌های استاندارد به‌صورت داخلی تعریف شده‌اند
        """
        print("🔌 Loading IEEE 33-bus network topology...")
        
        # داده‌های استاندارد IEEE 33-bus
        line_data = [
            (1, 2, 0.0922, 0.0470), (2, 3, 0.4930, 0.2511), (3, 4, 0.3660, 0.1864),
            (4, 5, 0.3811, 0.1941), (5, 6, 0.8190, 0.7070), (6, 7, 0.1872, 0.6188),
            (7, 8, 0.7114, 0.2351), (8, 9, 1.0300, 0.7400), (9, 10, 1.0440, 0.7400),
            (10, 11, 0.1966, 0.0650), (11, 12, 0.3744, 0.1238), (12, 13, 1.4680, 1.1550),
            (13, 14, 0.5416, 0.7129), (14, 15, 0.5910, 0.5260), (15, 16, 0.7463, 0.5450),
            (16, 17, 1.2890, 1.7210), (17, 18, 0.7320, 0.5740), (2, 19, 0.1640, 0.1565),
            (19, 20, 1.5042, 1.3554), (20, 21, 0.4095, 0.4784), (21, 22, 0.7089, 0.9373),
            (3, 23, 0.4512, 0.3083), (23, 24, 0.8980, 0.7091), (24, 25, 0.8960, 0.7011),
            (6, 26, 0.2030, 0.1034), (26, 27, 0.2842, 0.1447), (27, 28, 1.0590, 0.9337),
            (28, 29, 0.8042, 0.7006), (29, 30, 0.5075, 0.2585), (30, 31, 0.9744, 0.9630),
            (31, 32, 0.3105, 0.3619), (32, 33, 0.3410, 0.5302)
        ]
        
        # بارهای پایه (با کمی تصادفی برای تنوع)
        np.random.seed(42)
        load_data = [(1, 0.0, 0.0)] + [
            (i, np.random.uniform(0.05, 0.25), np.random.uniform(0.02, 0.1)) 
            for i in range(2, 34)
        ]
        
        lines_df = pd.DataFrame(line_data, columns=['from_bus', 'to_bus', 'R_pu', 'X_pu'])
        loads_df = pd.DataFrame(load_data, columns=['bus', 'P_mw', 'Q_mvar'])
        
        network_data = {
            'base_MVA': 100,
            'base_kV': 12.66,
            'num_buses': 33,
            'lines': lines_df.to_dict(orient='records'),
            'loads': loads_df.to_dict(orient='records'),
        }
        
        if save:
            # ذخیره در پوشه‌ی raw
            raw_path = self.raw_dir / "network" / "ieee33_bus.json"
            with open(raw_path, 'w') as f:
                json.dump(network_data, f, indent=2)
            
            # ذخیره در پوشه‌ی processed
            proc_path = self.processed_dir / "network_data.json"
            with open(proc_path, 'w') as f:
                json.dump(network_data, f, indent=2)
            
            print(f"✅ Network data saved to {proc_path}")
        
        self.metadata['sources']['network'] = {
            'source': 'IEEE 33-bus Test Feeder (embedded)',
            'timestamp': datetime.now().isoformat()
        }
        self._save_metadata()
        
        return network_data
    
    def _generate_synthetic_data(self, year=2023, country="DE"):
        """
        تولید داده‌های سینتتیک با الگوهای واقعی‌گرا
        شامل: بار، تولید خورشیدی، تولید بادی، قیمت بازار
        """
        print(f"📊 Generating synthetic data for {country} ({year})...")
        
        # تولید سری زمانی ساعتی برای یک سال کامل
        dates = pd.date_range(start=f"{year}-01-01 00:00:00", 
                              end=f"{year}-12-31 23:00:00", 
                              freq='h')
        n_hours = len(dates)
        hour = dates.hour
        day_of_year = dates.dayofyear
        is_weekend = (dates.dayofweek >= 5).astype(int)
        
        # ========================================
        # 1. داده‌های بار (Load)
        # ========================================
        # الگوی فصلی: پیک تابستان (روز ۱۸۰)، کمترین در زمستان (روز ۳۵۰)
        seasonal_load = 0.8 + 0.2 * np.sin(2 * np.pi * (day_of_year - 170) / 365)
        
        # الگوی روزانه: دو پیک (صبح ۸ و عصر ۱۸)
        daily_load = (0.7 + 0.3 * np.exp(-((hour - 8) / 3)**2) + 
                      0.3 * np.exp(-((hour - 18) / 2)**2))
        
        # کاهش بار در آخر هفته (۱۵٪ کمتر)
        weekend_factor = 0.85 + 0.15 * (1 - is_weekend)
        
        # بار پایه (برای فیدر ۳۳ باسه، حدود ۱۰-۲۰ مگاوات)
        base_load = 12.0
        load_mw = base_load * seasonal_load * daily_load * weekend_factor
        
        # افزودن نویز تصادفی (۵٪)
        noise = np.random.normal(0, 0.05, n_hours)
        load_mw = load_mw * (1 + noise)
        load_mw = np.maximum(load_mw, 0.5 * base_load)
        
        # ========================================
        # 2. داده‌های تولید خورشیدی (Solar)
        # ========================================
        # تابش خالص در آسمان صاف (از طلوع تا غروب)
        solar_clear = np.maximum(0, np.sin(np.pi * (hour - 5) / 12))
        # اثر فصلی: بیشترین در تابستان (روز ۱۷۰)
        solar_clear = solar_clear * np.maximum(0, np.sin(np.pi * (day_of_year - 80) / 365))
        solar_clear = np.maximum(solar_clear, 0)
        
        # ابرناکی: کاهش تصادفی بین ۰ تا ۵۰٪
        cloud_factor = 0.5 + 0.5 * np.random.beta(2, 2, n_hours)
        solar_power_mw = solar_clear * cloud_factor * 8.0  # حداکثر ۸ مگاوات
        
        # ========================================
        # 3. داده‌های تولید بادی (Wind)
        # ========================================
        # سرعت باد با توزیع وایبول (Weibull)
        wind_speed = np.random.weibull(2, n_hours) * 5.0
        
        # افزایش سرعت باد در شب
        wind_night = 1.2 - 0.4 * (hour < 6)
        wind_speed = wind_speed * wind_night
        wind_speed = np.clip(wind_speed, 0, 15)
        
        # منحنی توان توربین بادی (ساده‌شده)
        wind_power_mw = 0.5 * 1.225 * 10000 * 0.4 * (wind_speed ** 3) / 1e6
        wind_power_mw = np.clip(wind_power_mw, 0, 4.0)  # حداکثر ۴ مگاوات
        
        # ========================================
        # 4. داده‌های قیمت بازار (Price)
        # ========================================
        # الگوی فصلی: قیمت بالاتر در زمستان
        seasonal_price = 35 + 20 * np.sin(2 * np.pi * (day_of_year - 350) / 365)
        
        # الگوی روزانه: قیمت بالاتر در ساعات پیک (۸-۲۰)
        daily_price = 1.0 + 0.3 * np.exp(-((hour - 12) / 4)**2)
        
        # تخفیف آخر هفته
        weekend_discount = 1.0 - 0.15 * is_weekend
        
        # تأثیر تولید تجدیدپذیر بر قیمت (همبستگی منفی)
        renewable_effect = -0.1 * (solar_power_mw + wind_power_mw) + np.random.normal(0, 3, n_hours)
        
        price_eur_mwh = seasonal_price * daily_price * weekend_discount + renewable_effect
        price_eur_mwh = np.maximum(price_eur_mwh, 5.0)  # کف قیمت ۵ یورو
        
        # ========================================
        # ساخت دیتافریم نهایی
        # ========================================
        df = pd.DataFrame({
            'timestamp': dates,
            'load_mw': load_mw,
            'solar_power_mw': solar_power_mw,
            'wind_power_mw': wind_power_mw,
            'price_dayahead_eur_mwh': price_eur_mwh,
            'hour': hour,
            'day_of_week': dates.dayofweek,
            'month': dates.month
        })
        
        # ذخیره در پوشه‌ی processed
        df.to_csv(self.processed_dir / "combined_data.csv", index=False)
        df[['timestamp', 'load_mw']].to_csv(self.processed_dir / "load_data.csv", index=False)
        df[['timestamp', 'solar_power_mw', 'wind_power_mw']].to_csv(
            self.processed_dir / "renewable_data.csv", index=False
        )
        df[['timestamp', 'price_dayahead_eur_mwh']].to_csv(
            self.processed_dir / "price_data.csv", index=False
        )
        
        print(f"✅ Synthetic data generated: {len(df)} hours")
        print(f"   Load: {load_mw.min():.2f} - {load_mw.max():.2f} MW")
        print(f"   Solar: {solar_power_mw.max():.2f} MW (peak)")
        print(f"   Wind: {wind_power_mw.max():.2f} MW (peak)")
        print(f"   Price: {price_eur_mwh.min():.2f} - {price_eur_mwh.max():.2f} EUR/MWh")
        
        return df
    
    def load_all_data(self, source="synthetic", year=2023, country="DE", use_real=False):
        """
        بارگذاری تمام داده‌های مورد نیاز برای شبیه‌سازی
        
        Parameters:
        -----------
        source: str — 'synthetic' (همیشه از داده‌های ساخته‌شده استفاده می‌کند)
        year: int — سال مبنا
        country: str — کشور (فقط برای نام‌گذاری)
        use_real: bool — برای سازگاری با کدهای دیگر
        """
        print("=" * 60)
        print("📥 LOADING ALL DATA (SYNTHETIC MODE)")
        print("=" * 60)
        print(f"   Source: {source}")
        print(f"   Year: {year}")
        print(f"   Country: {country}")
        print("-" * 60)
        
        # ۱. بارگذاری شبکه
        data = {'network': self.load_ieee33_network()}
        
        # ۲. تولید داده‌های سینتتیک
        df = self._generate_synthetic_data(year, country)
        
        # ۳. استخراج دیتافریم‌های جداگانه
        data['load'] = df[['timestamp', 'load_mw']]
        data['renewable'] = df[['timestamp', 'solar_power_mw', 'wind_power_mw']]
        data['price'] = df[['timestamp', 'price_dayahead_eur_mwh']]
        
        # ۴. به‌روزرسانی متادیتا
        self.metadata['sources']['synthetic_data'] = {
            'source': 'Synthetic generator',
            'year': year,
            'country': country,
            'num_records': len(df),
            'timestamp': datetime.now().isoformat()
        }
        self._save_metadata()
        
        print("-" * 60)
        print("✅ ALL DATA LOADED SUCCESSFULLY")
        print(f"   Data stored in: {self.processed_dir}")
        print("=" * 60)
        
        return data


# ============================================================
# تست سریع
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("🧪 TESTING DATA LOADER")
    print("=" * 60)
    
    loader = DataLoader()
    data = loader.load_all_data()
    
    print("\n📊 Data summary:")
    for key, value in data.items():
        if key == 'network':
            print(f"  {key}: {value.get('num_buses', 'N/A')} buses")
        elif isinstance(value, pd.DataFrame):
            print(f"  {key}: {len(value)} rows, {len(value.columns)} columns")
            print(f"    Columns: {list(value.columns)}")
    
    print("\n✅ Test complete!")
