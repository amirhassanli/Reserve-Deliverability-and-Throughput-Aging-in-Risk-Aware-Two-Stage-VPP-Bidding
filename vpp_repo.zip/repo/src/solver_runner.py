"""
Solver Runner Module
Runs optimization for multiple days and seeds with full ablation cases
"""

import numpy as np
import pandas as pd
import json
import time
from pathlib import Path
from tqdm import tqdm
import yaml
import sys
sys.path.append(str(Path(__file__).parent))

from model_formulation import VPPModel
from pyomo.environ import TerminationCondition


class SolverRunner:
    def __init__(self, config_path="config/config.yaml"):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.output_dir = Path("output")
        self.results_dir = self.output_dir / "results"
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        self.num_seeds = self.config.get('num_seeds', 50)
        self.num_days = self.config.get('num_days', 28)
        self.horizon = self.config.get('time_horizon', 24)
        self.solver_time_limit = self.config.get('solver_time_limit', 3600)
        self.ablation_cases = self.config.get('ablation_cases', ['B0', 'B1', 'B2', 'B3', 'P1', 'P2', 'Full'])
        
        # Load network
        with open("data/processed/network_data.json", 'r') as f:
            self.network = json.load(f)
    
    def get_case_config(self, case_name):
        """Return component flags for each ablation case"""
        configs = {
            'B0': {'deg': 0.0, 'fdia': 0.0, 'lin_distflow': False, 'llm_gnn': False, 'marl': False},
            'B1': {'deg': 50.0, 'fdia': 0.0, 'lin_distflow': False, 'llm_gnn': False, 'marl': False},
            'B2': {'deg': 50.0, 'fdia': 0.0, 'lin_distflow': True, 'llm_gnn': False, 'marl': False},
            'B3': {'deg': 50.0, 'fdia': 10.0, 'lin_distflow': True, 'llm_gnn': False, 'marl': False},
            'P1': {'deg': 50.0, 'fdia': 10.0, 'lin_distflow': True, 'llm_gnn': True, 'marl': False},
            'P2': {'deg': 50.0, 'fdia': 10.0, 'lin_distflow': True, 'llm_gnn': True, 'marl': True},
            'Full': {'deg': 50.0, 'fdia': 10.0, 'lin_distflow': True, 'llm_gnn': True, 'marl': True}
        }
        return configs.get(case_name, configs['B0'])
    
    def load_scenarios_for_day(self, day_idx):
        """Load scenarios from saved JSON file"""
        scenario_file = Path(f"data/processed/scenario_data/scenarios_day_{day_idx}.json")
        if not scenario_file.exists():
            print(f"⚠️ Scenario file for day {day_idx} not found. Skipping.")
            return None
        
        with open(scenario_file, 'r') as f:
            day_data = json.load(f)
        return day_data['scenarios']
    
    def run_single_case(self, case_name, day_idx, seed):
        """Run a single case for one day with one seed"""
        # Load scenarios
        scenarios = self.load_scenarios_for_day(day_idx)
        if scenarios is None:
            return None
        
        # Get case config
        case_config = self.get_case_config(case_name)
        
        # Build model
        model = VPPModel(self.config, self.network)
        
        # Apply case-specific modifications
        model.deg_cost = case_config['deg']
        model.fdia_penalty = case_config['fdia']
        
        if not case_config['lin_distflow']:
            # Remove voltage constraints
            if hasattr(model.model, 'voltage_drop'):
                model.model.del_component(model.model.voltage_drop)
        
        if not case_config['llm_gnn']:
            # Fix prices to mean value (no LLM enhancement)
            for s in model.model.S:
                for t in model.model.T:
                    model.model.price[s,t].fix(
                        np.mean([sc['price'][t] for sc in scenarios])
                    )
        
        if not case_config['marl']:
            # No MARL-specific changes needed for centralized control
            pass
        
        # Build and solve
        model.build_model(scenarios)
        
        start_time = time.time()
        result_obj, solve_time = model.solve(seed=seed, tee=False)
        solve_time = time.time() - start_time
        
        if result_obj.solver.termination_condition != TerminationCondition.optimal:
            return None
        
        # Extract results
        extracted = model.extract_results()
        extracted['seed'] = seed
        extracted['day'] = day_idx
        extracted['case'] = case_name
        extracted['solve_time'] = solve_time
        extracted['degradation_cost'] = sum(
            extracted.get('degradation_cost', 0) for _ in range(self.horizon)
        )
        
        # Count voltage violations
        voltage_violations = 0
        if hasattr(model.model, 'V'):
            for s in model.model.S:
                for t in model.model.T:
                    if model.model.V[s,t].value < 0.95 or model.model.V[s,t].value > 1.05:
                        voltage_violations += 1
        extracted['voltage_violations'] = voltage_violations
        
        return extracted
    
    def run_all_cases(self):
        """Run all ablation cases for all days and all seeds"""
        print(f"🔬 Running {len(self.ablation_cases)} cases × {self.num_days} days × {self.num_seeds} seeds")
        print(f"   Total runs: {len(self.ablation_cases) * self.num_days * self.num_seeds}")
        
        all_results = []
        
        for case in self.ablation_cases:
            print(f"\n📊 Case: {case}")
            for day in tqdm(range(self.num_days), desc=f"  Days"):
                for seed in range(self.num_seeds):
                    result = self.run_single_case(case, day, seed)
                    if result:
                        all_results.append(result)
        
        # Convert to DataFrame
        df = pd.DataFrame(all_results)
        
        # Save full results
        output_path = self.results_dir / "ablation_results_full.csv"
        df.to_csv(output_path, index=False)
        print(f"\n✅ Full results saved to {output_path}")
        
        # Compute and save summary statistics
        summary = df.groupby('case').agg({
            'expected_profit': ['mean', 'std', 'min', 'max'],
            'solve_time': ['mean', 'std'],
            'voltage_violations': ['mean', 'max'],
        }).round(2)
        
        summary_path = self.results_dir / "ablation_summary.csv"
        summary.to_csv(summary_path)
        print(f"✅ Summary saved to {summary_path}")
        
        print("\n📊 Ablation Summary:")
        print(summary)
        
        return df, summary


if __name__ == "__main__":
    runner = SolverRunner()
    df, summary = runner.run_all_cases()