"""
Run Full Pipeline
Orchestrates all steps: data loading, scenario generation, ablation, sensitivity, validation, and figures
"""

import sys
import io
import time
from pathlib import Path
import yaml
import logging

# Fix encoding for Windows console
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Add src to path
sys.path.append(str(Path(__file__).parent))

from data_loader import DataLoader
from scenario_generator import ScenarioGenerator
from solver_runner import SolverRunner
from sensitivity_analyzer import SensitivityAnalyzer
from lin_distflow_validator import LinDistFlowValidator
from visualization import FigureGenerator


def setup_logging():
    log_dir = Path("output/logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "pipeline.log", encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)


def main():
    logger = setup_logging()
    logger.info("=" * 60)
    logger.info("STARTING FULL VPP OPTIMIZATION PIPELINE")
    logger.info("=" * 60)
    
    start_time = time.time()
    
    try:
        # Step 1: Load data
        logger.info("\nStep 1: Loading data...")
        loader = DataLoader()
        data = loader.load_all_data(source="synthetic", year=2023, country="DE")
        logger.info("Data loading complete")
        
        # Step 2: Generate scenarios (28 days)
        logger.info("\nStep 2: Generating scenarios for 28 days...")
        gen = ScenarioGenerator(data_dir="data")
        scenarios = gen.generate_and_save_scenarios(num_days=1)
        logger.info(f"Generated scenarios for {len(scenarios)} days")
        
        # Step 3: Run full ablation (7 cases × 1 day × 3 seeds)
        logger.info("\nStep 3: Running ablation study...")
        runner = SolverRunner()
        df_ablation, summary_ablation = runner.run_all_cases()
        logger.info("Ablation study complete")
        
        # Step 4: Run sensitivity analysis
        logger.info("\nStep 4: Running 3D sensitivity analysis...")
        analyzer = SensitivityAnalyzer()
        df_sensitivity, summary_sensitivity = analyzer.run_sensitivity_sweep()
        logger.info("Sensitivity analysis complete")
        
        # Step 5: Validate LinDistFlow
        logger.info("\nStep 5: Validating LinDistFlow...")
        validator = LinDistFlowValidator()
        ldf_summary, ldf_points = validator.validate(n_points=50)  # 50 points for testing
        logger.info("LinDistFlow validation complete")
        
        # Step 6: Generate figures
        logger.info("\nStep 6: Generating figures...")
        fig_gen = FigureGenerator()
        fig_gen.generate_all_figures()
        logger.info("Figures generated")
        
        # Step 7: Generate final tables
        logger.info("\nStep 7: Generating final tables...")
        # Save ablation table
        summary_ablation.to_csv("output/results/table1_ablation_results.csv")
        
        # Save sensitivity table (top 20 points)
        top_sensitivity = df_sensitivity.nlargest(20, 'expected_profit')
        top_sensitivity.to_csv("output/results/table2_sensitivity_top20.csv", index=False)
        
        logger.info("Tables saved")
        
        elapsed = time.time() - start_time
        logger.info("\n" + "=" * 60)
        logger.info(f"PIPELINE COMPLETED SUCCESSFULLY in {elapsed/60:.2f} minutes")
        logger.info("=" * 60)
        logger.info(f"   Results: output/results/")
        logger.info(f"   Figures: output/figures/")
        logger.info(f"   Logs: output/logs/")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
