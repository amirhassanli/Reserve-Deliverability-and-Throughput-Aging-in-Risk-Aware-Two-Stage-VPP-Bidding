"""
LinDistFlow Validator
Compares LinDistFlow with full AC-OPF (using pandapower if available)
"""

import numpy as np
import pandas as pd
import json
from pathlib import Path
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

# Try to import pandapower for AC-OPF
try:
    import pandapower as pp
    HAS_PANDAPOWER = True
except ImportError:
    HAS_PANDAPOWER = False
    print("⚠️ pandapower not installed. Using simplified AC-OPF approximation.")


class LinDistFlowValidator:
    def __init__(self, network_path="data/processed/network_data.json"):
        with open(network_path, 'r') as f:
            self.network = json.load(f)
        
        self.n_buses = self.network['num_buses']
        self.lines = self.network['lines']
        self.base_MVA = self.network['base_MVA']
        self.base_kV = self.network['base_kV']
        
        self.output_dir = Path("output")
        self.results_dir = self.output_dir / "results"
        self.results_dir.mkdir(parents=True, exist_ok=True)
    
    def build_pandapower_network(self):
        """Build IEEE 33-bus network in pandapower"""
        if not HAS_PANDAPOWER:
            return None
        
        net = pp.create_empty_network()
        
        # Add buses
        for i in range(self.n_buses):
            pp.create_bus(net, name=f"Bus {i+1}", vn_kv=self.base_kV)
        
        # Add slack bus (bus 0)
        pp.create_ext_grid(net, bus=0, vm_pu=1.0)
        
        # Add lines
        for line in self.lines:
            from_bus = line['from_bus'] - 1
            to_bus = line['to_bus'] - 1
            R = line['R_pu'] * 100  # Scale to ohms? Actually pandapower uses per-unit or ohms.
            X = line['X_pu'] * 100
            pp.create_line(net, from_bus=from_bus, to_bus=to_bus, length_km=1.0,
                           std_type="NAYY 4x50 SE")  # Temporary type
            # Set specific impedance
            net.line.at[net.line.index[-1], 'r_ohm_per_km'] = R
            net.line.at[net.line.index[-1], 'x_ohm_per_km'] = X
        
        return net
    
    def run_ac_power_flow_pandapower(self, P_load, Q_load=None):
        """Run AC-OPF using pandapower"""
        if not HAS_PANDAPOWER:
            return self.run_ac_power_flow_simplified(P_load, Q_load)
        
        net = self.build_pandapower_network()
        if net is None:
            return self.run_ac_power_flow_simplified(P_load, Q_load)
        
        # Set loads
        for i in range(self.n_buses):
            pp.create_load(net, bus=i, p_mw=P_load[i] * 100, q_mvar=(Q_load[i] if Q_load is not None else 0.3 * P_load[i]) * 100)
        
        # Run power flow
        try:
            pp.runpp(net, max_iteration=100, tolerance=1e-6)
            V_ac = net.res_bus['vm_pu'].values
            return V_ac
        except:
            return self.run_ac_power_flow_simplified(P_load, Q_load)
    
    def run_ac_power_flow_simplified(self, P_load, Q_load=None):
        """Simplified AC-OPF using Newton-Raphson approximation"""
        if Q_load is None:
            Q_load = 0.3 * P_load  # Assume PF ~0.95
        
        V = np.ones(self.n_buses)
        
        # Iterative approximation
        for _ in range(20):
            V_new = V.copy()
            for line in self.lines:
                i = line['from_bus'] - 1
                j = line['to_bus'] - 1
                R = line['R_pu']
                X = line['X_pu']
                
                # Power flow from i to j
                P_flow = P_load[i] + 0.5 * P_load[j]  # Approx
                Q_flow = Q_load[i] + 0.5 * Q_load[j]
                
                # Voltage drop
                dV = (R * P_flow + X * Q_flow) / V[i]
                V_new[j] = V[i] - dV
                V_new[j] = max(V_new[j], 0.90)  # Clamp
            
            V = V_new
        
        return V
    
    def run_lin_distflow(self, P_load, Q_load=None):
        """Run LinDistFlow (linearized power flow)"""
        if Q_load is None:
            Q_load = 0.3 * P_load
        
        V = np.ones(self.n_buses)
        
        for line in self.lines:
            i = line['from_bus'] - 1
            j = line['to_bus'] - 1
            R = line['R_pu']
            X = line['X_pu']
            
            # LinDistFlow: V_j = V_i - (R*P + X*Q)
            P_flow = sum(P_load[:j]) - sum(P_load[:i])
            Q_flow = sum(Q_load[:j]) - sum(Q_load[:i])
            
            V[j] = V[i] - (R * P_flow + X * Q_flow)
            V[j] = max(V[j], 0.90)
        
        return V
    
    def validate(self, n_points=1000):
        """Validate LinDistFlow against AC-OPF"""
        print(f"🔬 Validating LinDistFlow with {n_points} random operating points...")
        
        errors = []
        
        for _ in tqdm(range(n_points)):
            # Generate random loads
            P_load = np.random.uniform(0.05, 0.5, self.n_buses)
            Q_load = 0.3 * P_load + np.random.uniform(-0.05, 0.05, self.n_buses)
            Q_load = np.maximum(Q_load, 0)
            
            # Run AC-OPF
            V_ac = self.run_ac_power_flow_pandapower(P_load, Q_load)
            
            # Run LinDistFlow
            V_ldf = self.run_lin_distflow(P_load, Q_load)
            
            # Compute errors
            abs_error = np.abs(V_ac - V_ldf)
            rel_error = abs_error / (V_ac + 1e-6)
            
            errors.append({
                'MAE': np.mean(abs_error),
                'RMSE': np.sqrt(np.mean(abs_error**2)),
                'Max_Error': np.max(abs_error),
                'Max_Rel_Error': np.max(rel_error),
                'Mean_V_ac': np.mean(V_ac),
                'Mean_V_ldf': np.mean(V_ldf)
            })
        
        # Aggregate results
        df = pd.DataFrame(errors)
        summary = df.agg({
            'MAE': ['mean', 'std', 'max'],
            'RMSE': ['mean', 'std', 'max'],
            'Max_Error': ['mean', 'std', 'max'],
            'Max_Rel_Error': ['mean', 'std', 'max']
        }).round(6)
        
        # Save
        df.to_csv(self.results_dir / "lin_distflow_validation_points.csv", index=False)
        summary.to_csv(self.results_dir / "lin_distflow_validation_summary.csv")
        
        print("\n📊 LinDistFlow Validation Summary:")
        print(summary)
        
        return summary, df


if __name__ == "__main__":
    validator = LinDistFlowValidator()
    summary, df = validator.validate(n_points=500)