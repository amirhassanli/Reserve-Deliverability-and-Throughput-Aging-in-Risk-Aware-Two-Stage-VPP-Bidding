# Reserve Deliverability and Throughput Aging in Risk-Aware Two-Stage VPP Bidding

Authors: Amir Hassanli, Ali Reza Abbasi

## Contents
- `docs/manuscripts/` – manuscript versions (merged final .docx, IEEE HTML draft, LAHO draft)
- `docs/drafts/` – working draft and paper-structure notes
- `src/`, `config/` – early Pyomo pipeline (synthetic-data scaffold)
- `tools/` – project-generation helper scripts

## Evidence status (important)
- The HiGHS/`scipy.linprog` LPs behind the reported results (`src/vpp_two_stage.py`, SMARD data, `results/*.csv`) are **not yet in this repo** and must be added before the numerical claims are reproducible.
- The Pyomo pipeline in `src/` uses synthetic data and placeholder figures; it did NOT produce the paper's numbers.
- `laho_vpp_paper_final.docx` contains LLM/GNN/MARL/ST-AE results that were never evaluated; it is retained only as a superseded draft.
